package microwave.model

class Microwave() {

  // Accessed by View. You should edit this method as you build functionality
  def currentInstructions(): Instructions = {
    new Instructions(0, 0)
    // TODO
  }

  // Accessed by View. You should edit this method as you build functionality
  def doorOpen(): Boolean = {
    false
  }


  def openDoor(): Unit = {
    // TODO
  }

  def closeDoor(): Unit = {
    // TODO
  }

  def startPressed(): Unit = {
    // TODO
  }

  def powerLevelPressed(): Unit = {
    // TODO
  }

  def cookTimePressed(): Unit = {
    // TODO
  }

  def thirtySecondsPressed(): Unit = {
    // TODO
  }

  def popcornPressed(): Unit = {
    // TODO
  }

  def clearPressed(): Unit = {
    // TODO
  }

  def numberPressed(number: Int): Unit = {
    // TODO
  }

}
